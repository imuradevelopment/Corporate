// Lightweight include + link adjustment + header behaviors (no visual change)
(function () {
  'use strict';

  function getBasePath() {
    // GitHub Pages 配下やサブディレクトリでも動作するベースパス計算
    // 例: https://username.github.io/Corporate/branch/...
    const path = location.pathname;
    // 先頭のスラッシュを除去し、先頭ディレクトリを基準にする
    // 本プロジェクトはブランチルート直下にHTMLがある前提のため、空を返す
    return '';
  }

  function resolveHref(raw) {
    const cleaned = raw.replace(/^@\//, '').replace(/^\.\//, '');
    const base = getBasePath();
    return base ? base + cleaned : cleaned;
  }

  function adjustLinks(root) {
    root.querySelectorAll('a[data-href]').forEach((a) => {
      const t = a.getAttribute('data-href');
      if (!t) return;
      a.setAttribute('href', resolveHref(t));
    });
    const y = root.querySelector('#y');
    if (y) y.textContent = new Date().getFullYear();

    // 現在ページのaria-current設定
    const current = location.pathname.split('/').pop() || 'index.html';
    root.querySelectorAll('a[href]').forEach((a) => {
      try {
        const href = a.getAttribute('href');
        if (!href) return;
        const target = href.split('?')[0].split('#')[0].replace('./', '');
        if (target === current) a.setAttribute('aria-current', 'page');
      } catch {}
    });
  }

  function adjustPathsForDirectoryDepth() {
    // pages/ 配下かどうかで相対パスを補正（HTML自体は変更しない）
    const isInPages = /\/pages\//.test(location.pathname);

    // 1) アセット参照の補正（assets/, components/ がルート直下想定のため）
    //    link[href], script[src], img[src], meta og/twitter 画像
    if (isInPages) {
      document.querySelectorAll('link[href]').forEach((el) => {
        const href = el.getAttribute('href');
        if (!href) return;
        if (/^(?:\.\/)?assets\//.test(href)) el.setAttribute('href', '../' + href.replace(/^\.\//, ''));
        if (/^(?:\.\/)?components\//.test(href)) el.setAttribute('href', '../' + href.replace(/^\.\//, ''));
      });
      document.querySelectorAll('script[src]').forEach((el) => {
        const src = el.getAttribute('src');
        if (!src) return;
        if (/^(?:\.\/)?assets\//.test(src)) el.setAttribute('src', '../' + src.replace(/^\.\//, ''));
        if (/^(?:\.\/)?components\//.test(src)) el.setAttribute('src', '../' + src.replace(/^\.\//, ''));
      });
      document.querySelectorAll('img[src]').forEach((el) => {
        const src = el.getAttribute('src');
        if (!src) return;
        if (/^(?:\.\/)?assets\//.test(src)) el.setAttribute('src', '../' + src.replace(/^\.\//, ''));
      });
      // OGP/Twitter画像
      document.querySelectorAll('meta[property="og:image"], meta[name="twitter:image"]').forEach((el) => {
        const content = el.getAttribute('content');
        if (!content) return;
        if (/^(?:\.\/)?assets\//.test(content)) el.setAttribute('content', '../' + content.replace(/^\.\//, ''));
      });
    }

    // 2) ページ内リンク補正
    //    - ルート: about/services/portfolio/contact は pages/ 配下にある
    //    - pages/ 配下: index.html は 1 つ上にある
    document.querySelectorAll('a[href]').forEach((a) => {
      const href = a.getAttribute('href');
      if (!href || /^(https?:)?\/\//.test(href) || href.startsWith('#')) return;

      // ハッシュ付きのリンクにも対応するため、判定はパス本体で行い、設定時にハッシュを復元する
      const [hrefPath, hrefHash] = href.split('#');
      const hashSuffix = hrefHash ? '#' + hrefHash : '';

      const pageNames = ['about.html', 'services.html', 'portfolio.html', 'contact.html'];
      if (!isInPages && pageNames.includes(hrefPath) && !hrefPath.startsWith('pages/')) {
        a.setAttribute('href', 'pages/' + hrefPath + hashSuffix);
        return;
      }
      if (isInPages && (hrefPath === 'index.html' || hrefPath === './index.html')) {
        a.setAttribute('href', '../index.html' + hashSuffix);
      }
    });
  }

  function applySeoMetaFallbacks() {
    try {
      const cfg = window.SiteConfig || {};
      const configuredBase = (cfg.baseUrl || '').replace(/\/$/, '');
      const originBase = (location && location.origin) ? location.origin : '';
      const base = configuredBase || originBase;

      // canonical
      const canonical = document.querySelector('link[rel="canonical"]');
      if (canonical && (!canonical.getAttribute('href') || canonical.getAttribute('href') === '')) {
        // 優先: 設定されたbase。なければオリジン。クエリ/ハッシュは除外
        const abs = base ? base + location.pathname : location.href.split(/[?#]/)[0];
        canonical.setAttribute('href', abs);
      }

      // og:url
      const ogUrl = document.querySelector('meta[property="og:url"]');
      if (ogUrl && (!ogUrl.getAttribute('content') || ogUrl.getAttribute('content') === '')) {
        const abs = base ? base + location.pathname : location.href.split(/[?#]/)[0];
        ogUrl.setAttribute('content', abs);
      }

      // og:image / twitter:image 絶対URL化
      const ogImage = document.querySelector('meta[property="og:image"]');
      const twImage = document.querySelector('meta[name="twitter:image"]');
      if (cfg.ogImageAbsoluteUrl) {
        ogImage && ogImage.setAttribute('content', cfg.ogImageAbsoluteUrl);
        twImage && twImage.setAttribute('content', cfg.ogImageAbsoluteUrl);
      } else {
        const ensureAbs = (val) => {
          if (!val) return '';
          if (/^https?:\/\//i.test(val)) return val;
          try { return new URL(val, location.href).toString(); } catch { return val; }
        };
        if (ogImage) ogImage.setAttribute('content', ensureAbs(ogImage.getAttribute('content') || 'assets/img/ogp.png'));
        if (twImage) twImage.setAttribute('content', ensureAbs(twImage.getAttribute('content') || 'assets/img/ogp.png'));
      }
    } catch {}
  }

  async function include(selector, url) {
    const host = document.querySelector(selector);
    if (!host) return;
    try {
      // pages/ 配下では 1 つ上の components/ を参照
      const isInPages = /\/pages\//.test(location.pathname);
      const prefix = isInPages ? '../' : '';
      const res = await fetch(prefix + url);
      const html = await res.text();
      host.innerHTML = html;
      // 先に data-href を href へ解決し、その後にディレクトリ深度の補正を適用
      adjustLinks(host);
      adjustPathsForDirectoryDepth();
      initHeaderInteractions();
    } catch (e) {
      // file:// などでの fetch 失敗時フォールバック
      if (location.protocol === 'file:') {
        const templates = {
          header: `<!-- fallback header -->\n<nav class="c-nav" id="navbar">\n  <div class="o-container c-nav__container">\n    <a href="index.html" class="c-nav__brand">AI-Dev's</a>\n    <ul class="c-nav__menu">\n      <li><a href="index.html" class="c-nav__link">ホーム</a></li>\n      <li><a href="about.html" class="c-nav__link">会社概要</a></li>\n      <li><a href="services.html" class="c-nav__link">サービス</a></li>\n      <li><a href="portfolio.html" class="c-nav__link">実績</a></li>\n      <li><a href="contact.html" class="c-nav__link">お問い合わせ</a></li>\n    </ul>\n    <button class="c-nav__mobile-button" id="mobile-menu-btn" aria-label="メニューを開く">\n      <i class="fas fa-bars"></i>\n    </button>\n  </div>\n</nav>\n<div class="c-nav__mobile-overlay" id="mobile-menu-overlay"></div>\n<div class="c-nav__mobile" id="mobile-menu">\n  <div class="c-nav__mobile-header">\n    <a href="index.html" class="c-nav__brand">AI-Dev's</a>\n    <button class="c-nav__mobile-close" id="mobile-menu-close" aria-label="メニューを閉じる">\n      <i class="fas fa-times"></i>\n    </button>\n  </div>\n  <nav class="c-nav__mobile-nav">\n    <a href="index.html" class="c-nav__link">ホーム</a>\n    <a href="about.html" class="c-nav__link">会社概要</a>\n    <a href="services.html" class="c-nav__link">サービス</a>\n    <a href="portfolio.html" class="c-nav__link">実績</a>\n    <a href="contact.html" class="c-nav__link">お問い合わせ</a>\n  </nav>\n</div>`,
          footer: `<!-- fallback footer -->\n<footer class="c-footer">\n  <div class="o-container">\n    <div class="c-footer__grid">\n      <div>\n        <h3 class="c-footer__brand">AI-Dev's</h3>\n        <p style="color: var(--text-muted); line-height: 1.6;">\n          AI技術で未来を創造する<br>\n          革新的なソリューションプロバイダー\n        </p>\n      </div>\n      <div>\n        <h4 class="c-footer__heading">サービス</h4>\n        <ul class="c-footer__links">\n          <li><a href="services.html#ai-development">AI開発</a></li>\n          <li><a href="services.html#data-analytics">データ分析</a></li>\n          <li><a href="services.html#system-development">システム開発</a></li>\n        </ul>\n      </div>\n      <div>\n        <h4 class="c-footer__heading">企業情報</h4>\n        <ul class="c-footer__links">\n          <li><a href="about.html">会社概要</a></li>\n          <li><a href="portfolio.html">導入実績</a></li>\n          <li><a href="contact.html">お問い合わせ</a></li>\n        </ul>\n      </div>\n      <div>\n        <h4 class="c-footer__heading">フォローする</h4>\n        <div class="c-footer__social-links">\n          <a href="#" class="c-footer__social-link" aria-label="Twitter"><i class="fab fa-twitter"></i></a>\n          <a href="#" class="c-footer__social-link" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>\n          <a href="#" class="c-footer__social-link" aria-label="GitHub"><i class="fab fa-github"></i></a>\n        </div>\n      </div>\n    </div>\n    <div class="c-footer__bottom">\n      <p>&copy; <span id="y"></span> AI-Dev's. All rights reserved.</p>\n    </div>\n  </div>\n</footer>`
        };
        const key = selector.includes('header') ? 'header' : 'footer';
        host.innerHTML = templates[key];
        // 先に data-href を href へ解決し、その後にディレクトリ深度の補正を適用
        adjustLinks(host);
        adjustPathsForDirectoryDepth();
        initHeaderInteractions();
      } else {
        console.error('include failed:', url, e);
      }
    }
  }

  function initHeaderInteractions() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenuClose = document.getElementById('mobile-menu-close');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');
    const navbar = document.getElementById('navbar');

    if (!mobileMenu || !mobileMenuBtn) return;

    function trapFocus(container) {
      const focusable = container.querySelectorAll(
        'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'
      );
      if (!focusable.length) return () => {};
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      function handler(e) {
        if (e.key !== 'Tab') return;
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
      container.addEventListener('keydown', handler);
      return () => container.removeEventListener('keydown', handler);
    }

    let releaseFocus = () => {};

    function openMobileMenu() {
      mobileMenu.classList.add('active');
      mobileMenuOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
      mobileMenuBtn.setAttribute('aria-expanded', 'true');
      releaseFocus = trapFocus(mobileMenu);
      setTimeout(() => {
        const first = mobileMenu.querySelector('a, button');
        first && first.focus();
      }, 0);
    }
    function closeMobileMenu() {
      mobileMenu.classList.remove('active');
      mobileMenuOverlay.classList.remove('active');
      document.body.style.overflow = '';
      mobileMenuBtn.setAttribute('aria-expanded', 'false');
      releaseFocus();
      mobileMenuBtn.focus();
    }
    mobileMenuBtn.addEventListener('click', openMobileMenu);
    mobileMenuClose?.addEventListener('click', closeMobileMenu);
    mobileMenuOverlay?.addEventListener('click', closeMobileMenu);
    document.querySelectorAll('.c-nav__mobile-nav .c-nav__link').forEach((l) => {
      l.addEventListener('click', closeMobileMenu);
    });

    // Navbar scroll effect (passive listener)
    window.addEventListener(
      'scroll',
      function () {
        if (!navbar) return;
        if (window.scrollY > 50) navbar.classList.add('scrolled');
        else navbar.classList.remove('scrolled');
      },
      { passive: true }
    );

    // ESC でクローズ
    window.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileMenu.classList.contains('active')) {
        closeMobileMenu();
      }
    });
  }

  function prefersReducedMotion() {
    try { return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; }
  }

  function initScrollEnhancements() {
    if (document.getElementById('scroll-progress') || document.getElementById('backtotop')) return;

    // Scroll progress bar
    const progress = document.createElement('div');
    progress.id = 'scroll-progress';
    progress.className = 'c-scroll-progress';
    const bar = document.createElement('div');
    bar.className = 'c-scroll-progress__bar';
    bar.setAttribute('role', 'progressbar');
    bar.setAttribute('aria-label', 'スクロール進捗');
    bar.setAttribute('aria-valuemin', '0');
    bar.setAttribute('aria-valuemax', '100');
    bar.setAttribute('aria-valuenow', '0');
    progress.appendChild(bar);
    document.body.appendChild(progress);

    // Back to top button
    const back = document.createElement('button');
    back.id = 'backtotop';
    back.type = 'button';
    back.className = 'c-backtotop';
    back.setAttribute('aria-label', 'ページ先頭へ');
    back.innerHTML = '<i class="fas fa-arrow-up" aria-hidden="true"></i>';
    document.body.appendChild(back);

    // Saturation toggle button (top-right)
    const toggle = document.createElement('button');
    toggle.id = 'saturation-toggle';
    toggle.type = 'button';
    toggle.className = 'c-backtotop';
    toggle.style.right = '76px';
    toggle.setAttribute('aria-label', '彩度切り替え');
    toggle.innerHTML = '<i class="fas fa-adjust" aria-hidden="true"></i>';
    document.body.appendChild(toggle);

    function update() {
      const scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const pct = Math.min(100, Math.max(0, (scrollTop / max) * 100));
      bar.style.width = pct + '%';
      bar.setAttribute('aria-valuenow', String(Math.round(pct)));
      if (scrollTop > 400) back.classList.add('is-visible'); else back.classList.remove('is-visible');
      if (scrollTop > 100) toggle.classList.add('is-visible'); else toggle.classList.remove('is-visible');
    }

    let ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(function () { update(); ticking = false; });
      }
    }, { passive: true });
    window.addEventListener('resize', function () { update(); }, { passive: true });
    update();

    back.addEventListener('click', function () {
      if (prefersReducedMotion()) window.scrollTo(0, 0);
      else window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Saturation toggle behavior
    const stateKey = 'ui-saturation';
    function applySaturation(state) {
      if (state === 'muted') {
        document.documentElement.style.filter = 'saturate(0.8)';
      } else if (state === 'vivid') {
        document.documentElement.style.filter = 'saturate(1.15)';
      } else {
        document.documentElement.style.filter = '';
      }
    }
    let sat = localStorage.getItem(stateKey) || 'default';
    applySaturation(sat);
    toggle.addEventListener('click', function () {
      sat = sat === 'default' ? 'vivid' : sat === 'vivid' ? 'muted' : 'default';
      localStorage.setItem(stateKey, sat);
      applySaturation(sat);
    });
  }

  window.addEventListener('DOMContentLoaded', () => {
    adjustPathsForDirectoryDepth();
    applySeoMetaFallbacks();
    initScrollEnhancements();
    try { window.Common && Common.initHeroParallax && Common.initHeroParallax(); } catch {}
    try { window.Common && Common.initCardTilt && Common.initCardTilt({ selector: '.c-card' }); } catch {}
    try { window.Common && Common.initAOSOptimize && Common.initAOSOptimize(); } catch {}
    include('[data-include="header"]', 'components/header.html');
    include('[data-include="footer"]', 'components/footer.html');
  });
})();


